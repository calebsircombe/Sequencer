/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
EuclideanPlugInAudioProcessorEditor::EuclideanPlugInAudioProcessorEditor (EuclideanPlugInAudioProcessor& p)
: AudioProcessorEditor (&p), processor (p)
{
    for(int i = 0; i < 16; i++)
    {
        pads[i].setClickingTogglesState(true);
        pads[i].addListener(this);
        addAndMakeVisible(&pads[i]);
        pads[i].setColour(0x1000101, Colours::white);
    }

    addAndMakeVisible (openButton);
    openButton.setButtonText ("Load Sample...");
    openButton.onClick = [this] { openButtonClicked(); };
    openButton.setColour(0x1000100, Colours::black);
    
   /* addAndMakeVisible(tempo);
    tempo.setRange(0.0, 240.0);
    tempo.setTextBoxStyle(Slider::TextBoxRight, false, 100, 20);
    tempo.addAndMakeVisible(this); */
    
    setSize (300 , 500);

    startTimerHz(60);
}

EuclideanPlugInAudioProcessorEditor::~EuclideanPlugInAudioProcessorEditor()
{
}

//==============================================================================
void EuclideanPlugInAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (Colours::white);
    for (int i = 0; i < 16; i++)
    {
        if (processor.m_currentBeat == i)
        {
            pads[i].setColour(0x1000100, Colours::grey);
        }
        else{
            pads[i].setColour(0x1000100, Colours::black);
        }
    }
    
    FlexBox fb;
    fb.flexWrap = FlexBox::Wrap::wrap;
    fb.justifyContent = FlexBox::JustifyContent::center;
    fb.alignContent = FlexBox::AlignContent::center;
    for(int i = 0; i < 16; i++)
    {
        fb.items.add((FlexItem(pads[i]).withMinWidth((3*getLocalBounds().getWidth()/16)-2.0f).withMinHeight((3*getLocalBounds().getWidth()/16)-2.0f)).withMargin(1.0f));
    }
    fb.items.add((FlexItem(openButton).withMinWidth((3*getLocalBounds().getWidth()/4)-2.0f).withMinHeight((3*getLocalBounds().getWidth()/32)-2.0f)).withMargin(1.0f));
   // fb.items.add((FlexItem(tempo).withMinWidth((3*getLocalBounds().getWidth()/4)-2.0f).withMinHeight((3*getLocalBounds().getWidth()/32)-2.0f)).withMargin(1.0f));
    fb.performLayout(Rectangle<float>(getWidth()/8.0f, getHeight()/8.0f, getWidth()*3.0f/4.0f, getHeight()*3.0f/4.0f));
    
}

void EuclideanPlugInAudioProcessorEditor::resized()
{
     openButton.setBounds (10, 10, getWidth() - 20, 20);
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
}

void EuclideanPlugInAudioProcessorEditor::buttonClicked (Button* button)
{
    String message;
    
    for (int i = 0; i < 16; i++) {
        if (button == &pads[i]){
            auto value = pads[i].getToggleState();
            processor.padState[i] = value;
            if(value == 1)
            {
                //processor.padState[i] = true;
                std::cout <<"Step is on" << newLine;
                
            }
            if(value == 0)
            {
                //processor.padState[i] = false;
                std::cout <<"Step is off" << newLine;
            }
        }
    }
}


//void EuclideanPlugInAudioProcessorEditor::sliderValueChanged (Slider * slider)
//{
//}

void EuclideanPlugInAudioProcessorEditor::openButtonClicked()
{
    FileChooser chooser ("Select a Wave file shorter than 2 seconds to play...",
                         File::nonexistent,
                         "*.wav");
    
    if (chooser.browseForFileToOpen())
    {
        auto file = chooser.getResult();
        std::unique_ptr<AudioFormatReader> reader (processor.formatManager.createReaderFor (file)); // [2]
        
        if (reader.get() != nullptr)
        {
            auto duration = reader->lengthInSamples / reader->sampleRate;                 // [3]
            
            if (duration < 2)
            {
                processor.fileBuffer.setSize (reader->numChannels, (int) reader->lengthInSamples);  // [4]
                reader->read (&processor.fileBuffer,                                                // [5]
                              0,                                                          //  [5.1]
                              (int) reader->lengthInSamples,                              //  [5.2]
                              0,                                                          //  [5.3]
                              true,                                                       //  [5.4]
                              true);                                                      //  [5.5]
                position = 0;                                                             // [6]
            }
    }
}
}


void EuclideanPlugInAudioProcessorEditor::timerCallback()
{
     repaint();
}
