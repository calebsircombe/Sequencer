/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include "../JuceLibraryCode/JuceHeader.h"
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class EuclideanPlugInAudioProcessorEditor  : public AudioProcessorEditor,
                                             public TextButton::Listener,
                                           //  public Slider::Listener,
                                             public Timer



{
public:
    EuclideanPlugInAudioProcessorEditor (EuclideanPlugInAudioProcessor&);
    ~EuclideanPlugInAudioProcessorEditor();

    //==============================================================================
    void paint (Graphics&) override;
    void resized() override;


private:
    
    TextButton button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16;
    
    TextButton pads[16];
    
    TextButton openButton;
    
    Slider tempo;
    
    void buttonClicked(Button* button) override;
    void timerCallback() override;
  //  void sliderValueChanged (Slider * slider) override;
    void openButtonClicked();
    
    int count;
    int beat;
    
    
    
    int position;
    
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    EuclideanPlugInAudioProcessor& processor;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (EuclideanPlugInAudioProcessorEditor)
};
